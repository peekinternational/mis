<div class="layout-footer">
    <div class="layout-footer-body">
        <small class="version">Version 1.1.0</small>
        <small class="copyright">{{ date('Y') }} &copy; Job Call Me</small>
    </div>
</div>
