		@extends('frontend.layouts.app')

		@section('title', 'Evaluation')

		@section('content')
		<section id="company-box">
			<div class="container">
			<div class="row" style="background-color: white;">

			<div class="follow-companies6" style="background:#57768a;color:#fff;;margin-bottom:20px;">
                    <h3 style="margin-left: 15px">Job Evaluation Matrix</h3>
				</div>
          <div class="col-md-12" style="padding-bottom: 36px;">
				
				<br>
				<span style="font-size: 12px;">You've not evaluated any applicant for this job.</span>
				
				</div>
			   
				 </div>
			</div>
			</div>
		</section>
		@endsection
		@section('page-footer')
		<script type="text/javascript">
		</script>
		@endsection