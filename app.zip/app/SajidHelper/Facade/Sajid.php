<?php
namespace App\SajidHelper\Facade; 
use Illuminate\Support\Facades\Facade;

class Sajid extends Facade{
    protected static function getFacadeAccessor() { 
        return 'Sajid'; 
    } 
}
?><?php
